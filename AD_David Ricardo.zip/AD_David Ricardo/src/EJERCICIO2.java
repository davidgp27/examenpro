import java.util.Scanner;
public class EJERCICIO2 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Introducir un capital en euros");
        int capinicial = sc.nextInt();
        int i = 10;
        System.out.println("Introducir tipo de interes mensual");
        int periodo = sc.nextInt();

    }
}
